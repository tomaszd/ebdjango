function sleep(milliseconds) {
  var start = new Date().getTime();
  for (var i = 0; i < 1e7; i++) {
    if ((new Date().getTime() - start) > milliseconds){
      break;
    }
  }
}

function myFunctionCount() {
          document.getElementById("demo").innerHTML = "Started Counting";
          console.log(new Date());
          console.log('Dude!');
          sleep(1000);
          console.log(new Date());
          document.getElementById("demo").innerHTML = "2570$";
}

function myFunctionStopCount() {
          document.getElementById("demo").innerHTML = "STOP counting";
}


function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
